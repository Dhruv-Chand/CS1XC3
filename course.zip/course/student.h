/**
 * @file student.h
 * @author Dhruv Chand
 * @brief Library for student.c, which contains the student type definition and all of the function declarations.
 * @date 2022-04-10
 * 
 * 
 */

/**
 * @brief A student type struct definition
 * 
 * This is a student type definition that stores their first name, last name, ID, grades, and number of grades
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;
/**
 * @brief Function that adds new grade to a student's list of grades
 * 
 * @param student This is the student to add new grade to
 * @param grade This is the new grade to be added
 */
void add_grade(Student *student, double grade);
/**
 * @brief Function that calculates the average grade for a student
 * 
 * @param student This is the student to calculate the average for
 * @return The average for the student (double)
 */
double average(Student *student);
/**
 * @brief Function that prints the student's name, ID, grades, and average grade
 * 
 * @param student This is the student to print out information on
 */
void print_student(Student *student);
/**
 * @brief Function that generates a random student using a given total amount of grades
 * 
 * @param grades This is the total amount of grades that the student will have
 * @return The new student generated (Student*)
 */
Student* generate_random_student(int grades); 
