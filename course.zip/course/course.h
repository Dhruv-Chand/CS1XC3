/**
 * @file course.h
 * @author Dhruv Chand 
 * @brief Library for course.c, which stores the Course type definition and all of the Course function declarations.
 * @date 2022-04-10
 * 
 * 
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief A course type struct definition
 * 
 * This course type struct stores the name of the course, the code, the students enrolled in the course, and the total amount of students in the course
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief Function used to enroll students into a course
 * 
 * @param course This is the course to enroll students into
 * @param student This is the student to be enrolled into the course
 */
void enroll_student(Course *course, Student *student);

/**
 * @brief Function used to print the name of the course, the code, the total amount of students in the course, and the students enrolled in the course
 * 
 * @param course This is the course to print out information for
 */
void print_course(Course *course);

/**
 * @brief Function used to return the top student in a course
 * 
 * @param course This is the course to find the top student of
 * @return The top student (Student*) 
 */
Student *top_student(Course* course);

/**
 * @brief Function used to return which students are passing the course
 * 
 * @param course The course to find out how many are students are passing
 * @param total_passing Pointer to store total amount passing
 * @return Students that are passing (Student*) 
 */
Student *passing(Course* course, int *total_passing);


