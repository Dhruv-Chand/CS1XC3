var searchData=
[
  ['student_2ec_22',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh_23',['student.h',['../student_8h.html',1,'']]]
];
